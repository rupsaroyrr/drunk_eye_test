from flask import Flask, render_template, request
import os
import facemodel
import voicemodel

app = Flask(__name__)

@app.route('/')
def camera():
  return render_template('camera.html')


@app.route('/upload_photo', methods=['POST'])
def upload_photo():
  photo = request.files['photo']
  unique_filename = f"{int(time.time())}_{photo.filename}"  # Create a unique filename
  photo.save(os.path.join(os.getcwd(), unique_filename))


  val = facemodel.check_intoxicated(unique_filename)  # Use the unique filename

  with open('val.txt', 'w') as f:
    f.write(str(val))

  return render_template('voice_model.html')

@app.route('/upload_video', methods=['POST'])
def upload_video():
  video = request.files['video']
  unique_video_filename = f"{int(time.time())}_{video.filename}"  # Create a unique filename
  video.save(unique_video_filename)


  phrase = 'energetic happiness'

  with open('phrase.txt', 'w') as f:
    f.write(phrase)

  voicemodel.get_wav_file(unique_video_filename)  # Use the unique video filename


  val2 = voicemodel.check_slurring('test.wav', phrase)

  r = open('val.txt', 'r')
  val = r.read()
  val = float(val)
  res = val+val2

  print(res/2)

  if res/2 >= 0.6:
    return render_template('intoxicated.html')
  else:
    return render_template('not_intoxicated.html')

app.run(host='0.0.0.0',port=18)
