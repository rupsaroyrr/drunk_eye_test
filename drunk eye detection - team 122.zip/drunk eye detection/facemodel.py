import torch
from torchvision import transforms, datasets
import torch.nn as nn
import torch.optim as optim
from PIL import Image
import os
import shutil

# Ensure directories exist
directory_path = 'piece'
even_folder_path = 'sober'
odd_folder_path = 'drunk'

os.makedirs(even_folder_path, exist_ok=True)
os.makedirs(odd_folder_path, exist_ok=True)

# Check if directory exists before accessing it
if os.path.exists(directory_path):
    for filename in os.listdir(directory_path):
        if filename.endswith('.jpg'):
            try:
                number = int(filename.replace('piece', '').replace('.jpg', ''))
                if number % 2 == 0:
                    shutil.move(os.path.join(directory_path, filename), os.path.join(even_folder_path, filename))
                else:
                    shutil.move(os.path.join(directory_path, filename), os.path.join(odd_folder_path, filename))
            except ValueError:
                print(f"Skipping invalid filename: {filename}")
else:
    print(f"Error: Directory '{directory_path}' not found.")

# Define image transformations
img_transforms = transforms.Compose([
    transforms.Resize((50, 50)),
    transforms.Grayscale(),
    transforms.ToTensor()
])

# Load dataset
dataset_path = 'IMAGES'
if os.path.exists(dataset_path):
    training = datasets.ImageFolder(dataset_path, transform=img_transforms)
    train_loader = torch.utils.data.DataLoader(training, batch_size=3, shuffle=True)
else:
    print(f"Error: Dataset directory '{dataset_path}' not found.")
    train_loader = None  # Handle case where dataset is missing

# Define CNN Model
class Model(nn.Module):
    def _init_(self):
        super()._init_()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=5),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=5),
            nn.ReLU(),
            nn.Flatten()
        )
        self.fc = nn.Linear(64 * 42 * 42, 2)  # Adjust based on actual output shape

    def forward(self, x):
        x = self.conv_layers(x)
        return self.fc(x)

# Training Function
def train_model():
    if train_loader is None:
        print("Error: Cannot train model, dataset not found.")
        return

    model = Model()
    optimizer = optim.Adam(model.parameters(), lr=0.0001)
    loss_fn = nn.CrossEntropyLoss()

    for epoch in range(20):
        for batch in train_loader:
            X, y = batch
            output = model(X)
            loss = loss_fn(output, y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print(f'LOSS: {loss.item()}')
        torch.save(model.state_dict(), 'model.pth')

# Function to Check Intoxication
def check_intoxicated(image_path):
    if not os.path.exists('model.pth'):
        print("Error: Model file 'model.pth' not found. Train the model first.")
        return

    model = Model()
    model.load_state_dict(torch.load('model.pth'))  # Load trained model
    model.eval()  # Set to evaluation mode

    if not os.path.exists(image_path):
        print(f"Error: Image '{image_path}' not found.")
        return

    img = Image.open("C:\drunk eye detection\assets\letterbox-view-black-woman-eyes-260nw-1586631940.webp")
    img_transformed = img_transforms(img).unsqueeze(0)  # Add batch dimension

    with torch.no_grad():  # Disable gradient calculations
        output = model(img_transformed)
        predicted_class = torch.argmax(output)
    
    print("Predicted class:", predicted_class.item())