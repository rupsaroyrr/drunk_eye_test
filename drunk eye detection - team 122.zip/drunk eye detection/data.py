from PIL import Image
import os
import numpy as np
import shutil
import torch
import torchvision.transforms as transforms

# Initialize variables
x = 0
y = 0
set_y = []

# Define paths
base_path = os.getcwd()
drunk_images_path = os.path.join(base_path, 'assets')
piece_path = os.path.join(base_path, 'pieces')

# Ensure 'pieces' directory exists
if not os.path.exists(piece_path):
    os.makedirs(piece_path)

# Check if 'drunkImages' directory exists
if not os.path.exists(drunk_images_path):
    print("Error: 'drunkImages' directory not found.")
else:
    for filename in os.listdir(drunk_images_path):
        if filename.startswith('.'):
            continue  # Ignore hidden files

        file_path = os.path.join(drunk_images_path, filename)

        if os.path.isfile(file_path):
            try:
                im = Image.open(file_path)

                # Calculate the size of each piece
                width, height = im.size
                piece_width = width // 2
                piece_height = height // 2

                # Create 4 image pieces
                pieces = [
                    im.crop((i * piece_width, j * piece_height, (i + 1) * piece_width, (j + 1) * piece_height))
                    for i in range(2) for j in range(2)
                ]

                # Save the pieces
                for i, piece in enumerate(pieces):
                    x += 1
                    piece_filename = f"piece{x}.jpg"
                    piece.save(os.path.join(piece_path, piece_filename))

                    # Assign labels alternately between [1, 0] and [0, 1]
                    if y == 0:
                        set_y.append(torch.tensor([1, 0], dtype=torch.float32))
                        y = 1
                    else:
                        set_y.append(torch.tensor([0, 1], dtype=torch.float32))
                        y = 0

            except Exception as e:
                print(f"Error processing image {filename}: {e}")

# Convert images to tensors
tensors = []
transform = transforms.ToTensor()

for filename in os.listdir(piece_path):
    img_path = os.path.join(piece_path, filename)
    try:
        img = Image.open(img_path).convert("RGB")  # Ensure image has 3 color channels
        tensors.append(transform(img))
    except Exception as e:
        print(f"Error loading image {filename}: {e}")

# Flatten tensors for model input
set_x = [torch.flatten(tensor) for tensor in tensors]

# Pad sequences to make them equal length
if set_x:
    set_x = torch.nn.utils.rnn.pad_sequence(set_x, batch_first=True)
else:
    set_x = torch.tensor([])  # Handle case where no images were processed

def get_datasets():
    return set_x, set_y

# Optional: Delete the old drunkImages dataset (Uncomment if needed)
'''
if os.path.exists(drunk_images_path):
    shutil.rmtree(drunk_images_path)
    print("Deleted old drunkImages dataset.")
'''
